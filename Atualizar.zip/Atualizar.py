# myFirstStreamlitApp.py
#import the libraries
import streamlit as st
import sqlite3
import pandas as pd
import time

global txtID
global txtNAME
global txtAGE
global txtADDRESS
global txtSALARY

def exibir():
    conn = sqlite3.connect('test3.db')
    cursor = conn.cursor()
    cursor = conn.execute("SELECT ID, NAME, AGE, ADDRESS, SALARY from COMPANY")
    for row in cursor:
       st.write("ID = ", row[0])       
       st.write("NAME = ", row[1])
       st.write("AGE = ", row[2])
       st.write("ADDRESS = ", row[3])
       st.write("SALARY = ", row[4], "\n")       
    conn.close()



#2º)INSERT data and READ this data
conn = sqlite3.connect('test3.db')

IDpesq = str(st.sidebar.number_input("ID a pesquisar?", value=1, step=1))
#if st.sidebar.button('PESQUISAR'):
if IDpesq:
    conn = sqlite3.connect('test3.db')  
    cursor = conn.execute("SELECT ID, NAME, AGE, ADDRESS, SALARY from COMPANY where ID=?", IDpesq)
    for row in cursor:
        txtID = str(st.text_input("Digite ID: ", row[0]))            
        txtNAME = str(st.text_input('Nome Completo', row[1]))
        txtAGE = str(st.text_input("Digite idade: ", row[2]))
        txtADDRESS = str(st.text_input("Digite Endereço: ", row[3]))        
        txtSALARY = str(st.text_input("Salário: ", row[4]))
#txtNAME = st.text_input("Nome a atualizar:")
#txtAGE = st.text_input("Idade a atualizar:") 
#txtADDRESS = st.text_input("Endereço a atualizar:")
#txtSALARY = st.text_input("Salário a atualizar:")
 
submitted = st.button('Salvar Alteração')
if submitted:         
    #conn.execute('''UPDATE COMPANY set NAME=?, AGE=?, ADDRESS=?, SALARY=? where ID=?'''.format(str(txtNAME), str(txtAGE), str(txtADDRESS), str(txtSALARY), str(IDpesq)))
    sql_update = """
                UPDATE COMPANY
                SET NAME = ?,
                AGE = ?,
                ADDRESS = ?,
                SALARY = ?
                WHERE ID = ?
                """
    conn.execute(sql_update, (txtNAME, txtAGE, txtADDRESS, txtSALARY, IDpesq))
    #conn.execute("UPDATE COMPANY set NAME='Massaki', AGE='42', ADDRESS='RUA TESTE', SALARY='12000' where ID=1")
    conn.commit()
    conn.total_changes
    conn.close()        
    st.write("Records created successfully")
if st.button("Exibir"):
    exibir()